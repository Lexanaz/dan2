package model;

import java.util.List;

public class ZakazService {
    private ZakazDAO zakazDAO = new ZakazDAO();

    public ZakazService() {
    }
/*

    public ZakazEntity findZakaz(int id) {
        return zakazDAO.findById(id);
    }

    public void saveZakaz(ZakazEntity zak) {
        zakazDAO.save(zak);
    }

    public void deleteZakaz(ZakazEntity zak) {
        zakazDAO.delete(zak);
    }

    public void updateZakaz(ZakazEntity zak) {
        zakazDAO.update(zak);
    }

    public List<ZakazEntity> findAllZakaz() {
        return zakazDAO.findAll();
    }


*/


}